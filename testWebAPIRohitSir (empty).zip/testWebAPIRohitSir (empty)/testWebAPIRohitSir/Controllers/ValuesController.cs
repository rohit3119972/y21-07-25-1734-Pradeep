﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace testWebAPIRohitSir.Controllers
{
    [RoutePrefix("api/values")]
    public class ValuesController : ApiController
    {
        // GET api/values
        List<Employee> lstEmployee = null;
        public ValuesController()
        {
            lstEmployee = new List<Employee>()
            {
                new Employee{Id = 1, Name="Pradeep Kumar", PhoneNo ="9650321559", Address ="Dwarka"},
                new Employee{Id = 2, Name="Rohit Nayyar", PhoneNo ="242423424", Address ="Dwarka"},
                new Employee{Id = 3, Name="Kumar", PhoneNo ="3423423", Address ="Dwarka"},
                new Employee{Id = 4, Name="dfasf", PhoneNo ="9650321559", Address ="Dwarka"},
            };
        }

        [Route("CheckData")]
        [HttpGet]
        public Employee FunCheckData()
        {
            return lstEmployee.Where(wh => wh.Id == 2).FirstOrDefault();
        }

        [Route("CheckDataListFilter/{id}")]
        [HttpGet]
        public IEnumerable<Employee> FunCheckDataListFilter(int id)
        {
            return lstEmployee.Where(wh => wh.Id == id);
        }

        [Route("CheckDataList")]
        [HttpGet]
        public IEnumerable<Employee> FunCheckDataList()
        {
            return lstEmployee;
        }
    }
}

public class Employee
{
    public int Id { get; set; }
    public string Name { get; set; }
    public string PhoneNo { get; set; }
    public string Address { get; set; }
}
